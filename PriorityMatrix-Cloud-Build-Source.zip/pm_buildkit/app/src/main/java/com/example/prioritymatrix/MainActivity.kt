package com.example.prioritymatrix

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.UUID
import java.util.concurrent.TimeUnit

private data class Task(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val notes: String = "",
    val date: String,
    val quadrant: Int,
    val done: Boolean = false
)

private val quadrantTitles = listOf("DO FIRST", "SCHEDULE", "DELEGATE", "ELIMINATE")
private val quadrantSubtitles = listOf("Urgent + Important", "Not urgent + Important", "Urgent + Not important", "Not urgent + Not important")
private val quadrantBg = listOf(Color(0xFFFFEFED), Color(0xFFEDF4FF), Color(0xFFFFF5E2), Color(0xFFF0F2F4))
private val quadrantAccent = listOf(Color(0xFFB5473D), Color(0xFF315FAD), Color(0xFF93600B), Color(0xFF53616D))
private val ink = Color(0xFF172033)
private val muted = Color(0xFF697386)
private val canvas = Color(0xFFF6F7FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        setContent { PriorityMatrixApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PriorityMatrixApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("priority_matrix", Context.MODE_PRIVATE) }
    var tasks by remember { mutableStateOf(loadTasks(prefs.getString("tasks", "[]") ?: "[]")) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var mode by remember { mutableStateOf("DAY") }
    var tab by remember { mutableStateOf("BOARD") }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var initialQuadrant by remember { mutableIntStateOf(0) }
    var dailyReminder by remember { mutableStateOf(prefs.getBoolean("daily_reminder", false)) }
    var weeklyReminder by remember { mutableStateOf(prefs.getBoolean("weekly_reminder", false)) }
    var showDelete by remember { mutableStateOf<Task?>(null) }

    fun save(updated: List<Task>) {
        tasks = updated
        prefs.edit().putString("tasks", tasksToJson(updated)).apply()
    }

    val weekStart = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val weekEnd = weekStart.plusDays(6)
    val visibleTasks = tasks.filter { t ->
        val d = runCatching { LocalDate.parse(t.date) }.getOrNull() ?: return@filter false
        if (mode == "DAY") d == selectedDate else !d.isBefore(weekStart) && !d.isAfter(weekEnd)
    }
    val completed = visibleTasks.count { it.done }
    val progress = if (visibleTasks.isEmpty()) 0f else completed.toFloat() / visibleTasks.size

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Color(0xFF334E8C), onPrimary = Color.White, background = canvas, surface = Color.White, onSurface = ink, secondary = Color(0xFF6477A8))
    ) {
        Scaffold(
            containerColor = canvas,
            topBar = {
                TopAppBar(
                    title = { Column { Text("Priority Matrix", fontWeight = FontWeight.Bold, color = ink); Text("Make room for what matters", fontSize = 11.sp, color = muted) } },
                    actions = { TextButton(onClick = { selectedDate = LocalDate.now(); tab = "BOARD" }) { Text("Today") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = canvas)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == "BOARD", onClick = { tab = "BOARD" }, icon = { Icon(Icons.Default.Today, null) }, label = { Text("Board") })
                    NavigationBarItem(selected = tab == "INSIGHTS", onClick = { tab = "INSIGHTS" }, icon = { Icon(Icons.Default.Assessment, null) }, label = { Text("Insights") })
                    NavigationBarItem(selected = tab == "SETTINGS", onClick = { tab = "SETTINGS" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            },
            floatingActionButton = {
                if (tab == "BOARD") FloatingActionButton(onClick = { editing = null; initialQuadrant = 0; showEditor = true }, containerColor = Color(0xFF334E8C), contentColor = Color.White) { Icon(Icons.Default.Add, "Add task") }
            }
        ) { padding ->
            when (tab) {
                "BOARD" -> BoardScreen(
                    modifier = Modifier.padding(padding), mode = mode, onModeChange = { mode = it }, selectedDate = selectedDate,
                    onDateChange = { selectedDate = it }, weekStart = weekStart, visibleTasks = visibleTasks, completed = completed, progress = progress,
                    onAdd = { q -> initialQuadrant = q; editing = null; showEditor = true },
                    onEdit = { t -> editing = t; initialQuadrant = t.quadrant; showEditor = true },
                    onToggle = { t -> save(tasks.map { if (it.id == t.id) it.copy(done = !it.done) else it }) },
                    onDelete = { showDelete = it },
                    onMove = { t, q -> save(tasks.map { if (it.id == t.id) it.copy(quadrant = q) else it }) },
                    onCalendar = { addToCalendar(context, it) }
                )
                "INSIGHTS" -> InsightsScreen(Modifier.padding(padding), tasks, selectedDate, onDateChange = { selectedDate = it })
                else -> SettingsScreen(
                    Modifier.padding(padding), dailyReminder, weeklyReminder,
                    onDaily = { enabled ->
                        dailyReminder = enabled; prefs.edit().putBoolean("daily_reminder", enabled).apply()
                        if (enabled && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        setReminder(context, "daily_matrix", enabled, false)
                    },
                    onWeekly = { enabled ->
                        weeklyReminder = enabled; prefs.edit().putBoolean("weekly_reminder", enabled).apply()
                        if (enabled && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        setReminder(context, "weekly_matrix", enabled, true)
                    },
                    onExport = { uri -> exportPdf(context, uri, tasks, selectedDate) }
                )
            }
        }
    }

    if (showEditor) {
        TaskEditor(task = editing, defaultDate = selectedDate, defaultQuadrant = initialQuadrant, onDismiss = { showEditor = false }, onSave = { task ->
            save(if (editing == null) tasks + task else tasks.map { if (it.id == task.id) task else it })
            showEditor = false
        })
    }
    showDelete?.let { task ->
        AlertDialog(onDismissRequest = { showDelete = null }, title = { Text("Delete task?") }, text = { Text("‘${task.title}’ will be removed from your board.") },
            confirmButton = { TextButton(onClick = { save(tasks.filterNot { it.id == task.id }); showDelete = null }) { Text("Delete", color = Color(0xFFB3261E)) } },
            dismissButton = { TextButton(onClick = { showDelete = null }) { Text("Cancel") } })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BoardScreen(
    modifier: Modifier, mode: String, onModeChange: (String) -> Unit, selectedDate: LocalDate, onDateChange: (LocalDate) -> Unit,
    weekStart: LocalDate, visibleTasks: List<Task>, completed: Int, progress: Float,
    onAdd: (Int) -> Unit, onEdit: (Task) -> Unit, onToggle: (Task) -> Unit, onDelete: (Task) -> Unit,
    onMove: (Task, Int) -> Unit, onCalendar: (Task) -> Unit
) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(8.dp))
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 1.dp) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(5.dp)) {
                listOf("DAY", "WEEK").forEachIndexed { i, v ->
                    SegmentedButton(selected = mode == v, onClick = { onModeChange(v) }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(if (v == "DAY") "Daily board" else "Weekly board") }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Surface(color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    IconButton(onClick = { onDateChange(selectedDate.minusDays(if (mode == "DAY") 1 else 7)) }) { Icon(Icons.Default.ArrowBack, "Previous period") }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text(if (mode == "DAY") selectedDate.format(DateTimeFormatter.ofPattern("EEEE, d MMM yyyy")) else "${weekStart.format(DateTimeFormatter.ofPattern("d MMM"))} – ${weekStart.plusDays(6).format(DateTimeFormatter.ofPattern("d MMM yyyy"))}", fontWeight = FontWeight.Bold, color = ink)
                        Text("$completed of ${visibleTasks.size} completed", fontSize = 11.sp, color = muted)
                    }
                    IconButton(onClick = { onDateChange(selectedDate.plusDays(if (mode == "DAY") 1 else 7)) }) { Icon(Icons.Default.ArrowForward, "Next period") }
                }
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Color(0xFF3D7B69), trackColor = Color(0xFFE9EDF2))
                if (mode == "WEEK") {
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        (0..6).forEach { offset ->
                            val day = weekStart.plusDays(offset.toLong()); val selected = day == selectedDate
                            Surface(color = if (selected) Color(0xFF334E8C) else Color(0xFFF0F2F7), shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f).clickable { onDateChange(day) }) {
                                Column(Modifier.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(day.dayOfWeek.name.take(1), fontSize = 10.sp, color = if (selected) Color.White.copy(.8f) else muted)
                                    Text(day.dayOfMonth.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selected) Color.White else ink)
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("IMPORTANT", Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = muted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text("NOT IMPORTANT", Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = muted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
        Text("URGENT  ↓", fontSize = 9.sp, color = muted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuadrantCard(0, visibleTasks, onAdd, onEdit, onToggle, onDelete, onMove, onCalendar, Modifier.weight(1f))
            QuadrantCard(2, visibleTasks, onAdd, onEdit, onToggle, onDelete, onMove, onCalendar, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("NOT URGENT  ↓", fontSize = 9.sp, color = muted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuadrantCard(1, visibleTasks, onAdd, onEdit, onToggle, onDelete, onMove, onCalendar, Modifier.weight(1f))
            QuadrantCard(3, visibleTasks, onAdd, onEdit, onToggle, onDelete, onMove, onCalendar, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun QuadrantCard(
    quadrant: Int, tasks: List<Task>, onAdd: (Int) -> Unit, onEdit: (Task) -> Unit, onToggle: (Task) -> Unit,
    onDelete: (Task) -> Unit, onMove: (Task, Int) -> Unit, onCalendar: (Task) -> Unit, modifier: Modifier = Modifier
) {
    val qTasks = tasks.filter { it.quadrant == quadrant }.sortedBy { it.done }
    Surface(modifier = modifier.fillMaxHeight(), color = quadrantBg[quadrant], shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.fillMaxSize().padding(9.dp)) {
            Text(quadrantTitles[quadrant], fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = quadrantAccent[quadrant], letterSpacing = .5.sp)
            Text(quadrantSubtitles[quadrant], fontSize = 9.sp, color = quadrantAccent[quadrant].copy(alpha = .88f), lineHeight = 12.sp)
            Spacer(Modifier.height(5.dp))
            Text("${qTasks.size} tasks", fontSize = 10.sp, color = quadrantAccent[quadrant].copy(alpha = .85f))
            Spacer(Modifier.height(6.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(qTasks, key = { it.id }) { task ->
                    TaskCard(task, onEdit, onToggle, onDelete, onMove, onCalendar)
                }
            }
            TextButton(onClick = { onAdd(quadrant) }, contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp), modifier = Modifier.height(32.dp)) {
                Icon(Icons.Default.Add, null, Modifier.size(14.dp)); Spacer(Modifier.width(3.dp)); Text("Add task", fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun TaskCard(task: Task, onEdit: (Task) -> Unit, onToggle: (Task) -> Unit, onDelete: (Task) -> Unit, onMove: (Task, Int) -> Unit, onCalendar: (Task) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Surface(color = Color.White, shape = RoundedCornerShape(12.dp), shadowElevation = 1.dp) {
        Column(Modifier.padding(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = task.done, onCheckedChange = { onToggle(task) }, modifier = Modifier.size(25.dp))
                Spacer(Modifier.width(3.dp))
                Text(task.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (task.done) muted else ink, modifier = Modifier.weight(1f), maxLines = 3)
            }
            if (task.notes.isNotBlank()) Text(task.notes, fontSize = 9.sp, color = muted, modifier = Modifier.padding(start = 28.dp, bottom = 3.dp), maxLines = 3)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Box {
                    TextButton(onClick = { menu = true }, contentPadding = PaddingValues(horizontal = 4.dp), modifier = Modifier.height(26.dp)) { Text("Move", fontSize = 9.sp) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        quadrantTitles.forEachIndexed { index, label ->
                            DropdownMenuItem(text = { Text(label, fontSize = 12.sp) }, onClick = { onMove(task, index); menu = false }, enabled = index != task.quadrant)
                        }
                    }
                }
                IconButton(onClick = { onCalendar(task) }, modifier = Modifier.size(27.dp)) { Icon(Icons.Default.Event, "Add to calendar", tint = muted, modifier = Modifier.size(14.dp)) }
                IconButton(onClick = { onEdit(task) }, modifier = Modifier.size(27.dp)) { Icon(Icons.Default.Edit, "Edit", tint = muted, modifier = Modifier.size(14.dp)) }
                IconButton(onClick = { onDelete(task) }, modifier = Modifier.size(27.dp)) { Icon(Icons.Default.Delete, "Delete", tint = muted, modifier = Modifier.size(14.dp)) }
            }
            if (task.date != LocalDate.now().toString()) Text(task.date, fontSize = 8.sp, color = muted, modifier = Modifier.padding(start = 28.dp))
        }
    }
}

@Composable
private fun InsightsScreen(modifier: Modifier, tasks: List<Task>, selectedDate: LocalDate, onDateChange: (LocalDate) -> Unit) {
    val start = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val week = tasks.filter { val d = runCatching { LocalDate.parse(it.date) }.getOrNull(); d != null && !d.isBefore(start) && !d.isAfter(start.plusDays(6)) }
    val done = week.count { it.done }; val pending = week.size - done
    val rate = if (week.isEmpty()) 0 else (done * 100 / week.size)
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Weekly insights", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = ink)
        Text("A clearer view of how your time is being spent.", color = muted, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { onDateChange(selectedDate.minusWeeks(1)) }) { Icon(Icons.Default.ArrowBack, null); Text("Previous") }
            Text("${start.format(DateTimeFormatter.ofPattern("d MMM"))} – ${start.plusDays(6).format(DateTimeFormatter.ofPattern("d MMM yyyy"))}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            OutlinedButton(onClick = { onDateChange(selectedDate.plusWeeks(1)) }) { Text("Next"); Icon(Icons.Default.ArrowForward, null) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Total tasks", week.size.toString(), "Created this week", Modifier.weight(1f))
            MetricCard("Completed", done.toString(), "$rate% completion", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Pending", pending.toString(), "Still on your list", Modifier.weight(1f))
            MetricCard("Do first", week.count { it.quadrant == 0 && !it.done }.toString(), "Urgent + important", Modifier.weight(1f))
        }
        Surface(color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Task distribution", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                quadrantTitles.forEachIndexed { i, title ->
                    val count = week.count { it.quadrant == i }
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = quadrantAccent[i]); Text("$count", fontSize = 11.sp, color = muted) }
                        LinearProgressIndicator(progress = { if (week.isEmpty()) 0f else count.toFloat() / week.size }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), color = quadrantAccent[i], trackColor = Color(0xFFF0F2F5))
                    }
                }
            }
        }
        Surface(color = Color(0xFFEAF1FF), shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF315FAD), modifier = Modifier.size(25.dp)); Spacer(Modifier.width(10.dp))
                Text(if (week.isEmpty()) "Add a few tasks to start seeing your weekly patterns." else "${if (rate >= 75) "Strong execution" else if (rate >= 40) "Good momentum" else "Room to improve"}. Review your unfinished tasks and plan the next action.", fontSize = 12.sp, color = Color(0xFF294B83))
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color.White, shape = RoundedCornerShape(17.dp), shadowElevation = 1.dp) {
        Column(Modifier.padding(14.dp)) { Text(title, fontSize = 11.sp, color = muted); Spacer(Modifier.height(5.dp)); Text(value, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = ink); Text(caption, fontSize = 10.sp, color = muted) }
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier, daily: Boolean, weekly: Boolean, onDaily: (Boolean) -> Unit, onWeekly: (Boolean) -> Unit, onExport: (Uri) -> Unit) {
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri -> if (uri != null) onExport(uri) }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = ink)
        Text("Keep your planning rhythm consistent.", color = muted, fontSize = 13.sp)
        Surface(color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.NotificationsActive, null, tint = Color(0xFF334E8C)); Spacer(Modifier.width(9.dp)); Text("Planning reminders", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                Spacer(Modifier.height(8.dp))
                SettingSwitch("Daily review", "A daily nudge to review your priorities", daily, onDaily)
                Divider(color = Color(0xFFF0F1F4))
                SettingSwitch("Weekly planning", "A weekly nudge to plan the week ahead", weekly, onWeekly)
            }
        }
        Surface(color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.FileDownload, null, tint = Color(0xFF334E8C)); Spacer(Modifier.width(9.dp)); Text("Export & reports", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                Text("Create a PDF report of your selected week, including task status and quadrant allocation.", color = muted, fontSize = 12.sp)
                Button(onClick = { exportLauncher.launch("priority-matrix-weekly-report.pdf") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(7.dp)); Text("Export weekly PDF") }
            }
        }
        Surface(color = Color(0xFFF0F3F9), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(14.dp)) { Text("About Priority Matrix", fontWeight = FontWeight.SemiBold, color = ink); Text("Your tasks are stored locally on this device. Calendar events are added through your device's calendar app. Reminders are scheduled locally.", fontSize = 11.sp, color = muted) }
        }
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = ink); Text(subtitle, fontSize = 10.sp, color = muted) }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TaskEditor(task: Task?, defaultDate: LocalDate, defaultQuadrant: Int, onDismiss: () -> Unit, onSave: (Task) -> Unit) {
    var title by remember(task?.id) { mutableStateOf(task?.title ?: "") }
    var notes by remember(task?.id) { mutableStateOf(task?.notes ?: "") }
    var date by remember(task?.id) { mutableStateOf(task?.date ?: defaultDate.toString()) }
    var quadrant by remember(task?.id) { mutableIntStateOf(task?.quadrant ?: defaultQuadrant) }
    var dateError by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (task == null) "New task" else "Edit task", fontWeight = FontWeight.Bold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task title") }, singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes (optional)") }, minLines = 2)
            OutlinedTextField(value = date, onValueChange = { date = it; dateError = false }, label = { Text("Date (YYYY-MM-DD)") }, singleLine = true, isError = dateError)
            if (dateError) Text("Enter a valid date in YYYY-MM-DD format", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            Text("Priority quadrant", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            quadrantTitles.forEachIndexed { i, label ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (quadrant == i) quadrantBg[i] else Color.Transparent).clickable { quadrant = i }.padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = quadrant == i, onClick = { quadrant = i })
                    Column { Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = quadrantAccent[i]); Text(quadrantSubtitles[i], fontSize = 10.sp, color = muted) }
                }
            }
        }
    }, confirmButton = {
        Button(onClick = {
            val parsed = runCatching { LocalDate.parse(date) }.getOrNull()
            if (title.isBlank() || parsed == null) { dateError = parsed == null; return@Button }
            onSave(Task(id = task?.id ?: UUID.randomUUID().toString(), title = title.trim(), notes = notes.trim(), date = parsed.toString(), quadrant = quadrant, done = task?.done ?: false))
        }) { Text("Save task") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

private class MatrixReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val weekly = inputData.getBoolean("weekly", false)
        val title = if (weekly) "Plan your week" else "Review your priorities"
        val message = if (weekly) "Take a few minutes to organise the week ahead in Priority Matrix." else "Check your urgent and important tasks for today."
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(applicationContext, "matrix_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) manager.notify(if (weekly) 202 else 201, notification)
        return Result.success()
    }
}

private fun setReminder(context: Context, name: String, enabled: Boolean, weekly: Boolean) {
    val work = WorkManager.getInstance(context)
    if (!enabled) { work.cancelUniqueWork(name); return }
    val target = if (weekly) LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)) else LocalDate.now()
    val time = if (weekly) LocalTime.of(18, 0) else LocalTime.of(20, 0)
    var next = LocalDateTime.of(target, time)
    if (!next.isAfter(LocalDateTime.now())) next = next.plusDays(if (weekly) 7 else 1)
    val delay = Duration.between(LocalDateTime.now(), next).toMillis().coerceAtLeast(0)
    val request = PeriodicWorkRequestBuilder<MatrixReminderWorker>(if (weekly) 7L else 1L, TimeUnit.DAYS)
        .setInitialDelay(delay, TimeUnit.MILLISECONDS)
        .setInputData(workDataOf("weekly" to weekly))
        .build()
    work.enqueueUniquePeriodicWork(name, ExistingPeriodicWorkPolicy.UPDATE, request)
}

private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel("matrix_reminders", "Priority Matrix reminders", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "Daily and weekly planning reminders" }
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }
}

private fun addToCalendar(context: Context, task: Task) {
    val date = runCatching { LocalDate.parse(task.date) }.getOrNull() ?: return
    val start = date.atTime(9, 0).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
    val intent = Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI)
        .putExtra(android.provider.CalendarContract.Events.TITLE, task.title)
        .putExtra(android.provider.CalendarContract.Events.DESCRIPTION, task.notes.ifBlank { quadrantSubtitles[task.quadrant] })
        .putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
        .putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, start + 60 * 60 * 1000)
    runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun exportPdf(context: Context, uri: Uri, tasks: List<Task>, selectedDate: LocalDate) {
    val start = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val end = start.plusDays(6)
    val weekTasks = tasks.filter { val d = runCatching { LocalDate.parse(it.date) }.getOrNull(); d != null && !d.isBefore(start) && !d.isAfter(end) }.sortedWith(compareBy<Task> { it.quadrant }.thenBy { it.date })
    val pdf = PdfDocument()
    val pageWidth = 595; val pageHeight = 842
    val titlePaint = Paint().apply { textSize = 22f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = android.graphics.Color.rgb(31, 47, 78) }
    val subPaint = Paint().apply { textSize = 11f; color = android.graphics.Color.DKGRAY }
    val headPaint = Paint().apply { textSize = 13f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = android.graphics.Color.rgb(48, 76, 137) }
    val bodyPaint = Paint().apply { textSize = 10f; color = android.graphics.Color.DKGRAY }
    val linePaint = Paint().apply { color = android.graphics.Color.LTGRAY; strokeWidth = 1f }
    var pageNumber = 1; var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()); var y = 55f
    fun newPage() { pdf.finishPage(page); pageNumber++; page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()); y = 50f }
    val c = page.canvas
    c.drawText("PRIORITY MATRIX", 40f, y, titlePaint); y += 24f
    c.drawText("Weekly report  •  ${start.format(DateTimeFormatter.ofPattern("d MMM yyyy"))} – ${end.format(DateTimeFormatter.ofPattern("d MMM yyyy"))}", 40f, y, subPaint); y += 28f
    val done = weekTasks.count { it.done }; c.drawText("Tasks: ${weekTasks.size}     Completed: $done     Pending: ${weekTasks.size - done}", 40f, y, subPaint); y += 26f
    for (q in 0..3) {
        if (y > 770f) newPage()
        page.canvas.drawText("${quadrantTitles[q]}  —  ${quadrantSubtitles[q]}", 40f, y, headPaint); y += 18f
        val group = weekTasks.filter { it.quadrant == q }
        if (group.isEmpty()) { page.canvas.drawText("No tasks", 52f, y, bodyPaint); y += 16f }
        group.forEach { t ->
            if (y > 780f) newPage()
            val status = if (t.done) "[DONE]" else "[OPEN]"
            page.canvas.drawText("$status  ${t.date}  •  ${t.title.take(75)}", 52f, y, bodyPaint); y += 15f
            if (t.notes.isNotBlank()) { page.canvas.drawText("      ${t.notes.take(95)}", 52f, y, bodyPaint); y += 14f }
        }
        y += 10f; page.canvas.drawLine(40f, y, 555f, y, linePaint); y += 17f
    }
    pdf.finishPage(page)
    runCatching { context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) } }
    pdf.close()
}

private fun tasksToJson(tasks: List<Task>): String {
    val array = JSONArray()
    tasks.forEach { t -> array.put(JSONObject().put("id", t.id).put("title", t.title).put("notes", t.notes).put("date", t.date).put("quadrant", t.quadrant).put("done", t.done)) }
    return array.toString()
}

private fun loadTasks(raw: String): List<Task> = runCatching {
    val array = JSONArray(raw)
    (0 until array.length()).map { i ->
        val o = array.getJSONObject(i)
        Task(id = o.optString("id", UUID.randomUUID().toString()), title = o.optString("title"), notes = o.optString("notes"), date = o.optString("date", LocalDate.now().toString()), quadrant = o.optInt("quadrant", 0).coerceIn(0, 3), done = o.optBoolean("done", false))
    }
}.getOrDefault(emptyList())
