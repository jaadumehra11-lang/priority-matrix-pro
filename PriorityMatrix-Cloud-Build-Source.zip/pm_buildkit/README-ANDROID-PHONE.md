# Build Priority Matrix Pro APK using only your Android phone

This project includes a GitHub Actions workflow. GitHub's cloud runner compiles the Android app; you do not need Android Studio, a laptop, or a local SDK.

## One-time setup (phone browser)

1. Sign in or create a free account at https://github.com.
2. In GitHub, tap **New repository**. Name it `priority-matrix-pro`, choose **Private** or **Public**, and create it.
3. Open the new, empty repository. Use **Add file → Upload files**.
4. Upload the **contents** of this project folder (not the outer ZIP itself). Make sure the hidden `.github/workflows/android-apk.yml` file is included at exactly that path. On Android, enable **Show hidden files** in your file manager if needed. If GitHub's mobile upload picker cannot select folders, use Chrome's **Desktop site** mode and upload the project files while preserving their folder paths.
5. Commit the upload to the `main` branch.

## Get the APK

1. Open the repository's **Actions** tab.
2. Select **Build Priority Matrix APK**. If it has not started automatically, tap **Run workflow** and select `main`.
3. Wait for the run to finish with a green check mark. Open the successful run.
4. Under **Artifacts**, download `PriorityMatrix-Android-APK`.
5. Extract the downloaded artifact ZIP. Inside it you will find `PriorityMatrix-APK.zip` and `PriorityMatrix.apk`.
6. Extract `PriorityMatrix-APK.zip` to get `PriorityMatrix.apk`, then tap the APK to install. Android may ask you to allow installation from your browser or file manager; only enable this for the app you intentionally downloaded.

## Notes

- The workflow builds a **debug APK**. It is installable for personal testing, but it is not a Play Store release and is not signed with a personal release key.
- GitHub Actions may require you to verify your email/account and enable Actions for the repository.
- If the workflow fails, open the failed run and inspect the **Build Android APK** logs. The cloud build is the point where compilation is actually verified; this source archive itself is not a prebuilt APK.
- Each successful run keeps its artifact for 30 days.
