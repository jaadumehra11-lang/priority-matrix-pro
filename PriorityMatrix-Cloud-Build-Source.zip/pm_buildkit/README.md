# Priority Matrix Pro (Android)

A native Android app for day-wise and week-wise Eisenhower Matrix planning.

## Features

- **Daily and weekly 2×2 boards** — Do First, Schedule, Delegate, Eliminate.
- **Task management** — create, edit, complete, delete, date and notes.
- **Quick quadrant movement** — move a task between all four priority quadrants from its Move menu.
- **Weekly insights** — completion rate, pending work, urgent-important count and quadrant distribution.
- **Daily and weekly reminders** — optional local notifications (daily target 8:00 PM; weekly target Sunday 6:00 PM). Android notification permission is requested when enabled. WorkManager may defer delivery according to Android battery and background limits.
- **Calendar hand-off** — open the device calendar's event editor pre-filled with task title, notes and date; user confirms/saves the event in their calendar app.
- **PDF export** — create a weekly PDF report through Android's document picker.
- **Offline-first storage** — tasks and reminder preferences are stored on-device; no account or cloud sync.

## Build and install

1. Install Android Studio with Android SDK Platform 35 and JDK 17 or newer.
2. Open the `PriorityMatrix` project folder in Android Studio.
3. Allow Gradle to sync and download the declared dependencies.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run** to install the app.
6. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio displays the output location.

Package: `com.example.prioritymatrix`  
Version: `2.0`  
Minimum Android: Android 8.0 (API 26)  
Compile/target SDK: 35

## Notes and limitations

- Data remains on this device and is not cloud-synced or shared across devices.
- The weekly board shows Monday–Sunday. Selecting a weekday in the strip focuses the daily board date when switching back to Daily.
- Calendar integration uses Android's standard calendar insert flow; it does not silently write calendar entries.
- Reminders use WorkManager periodic scheduling. Android can defer notifications; exact-to-the-minute delivery is not guaranteed.
- Tasks can be moved between quadrants with the **Move** action on each task card. This release uses an explicit move control rather than gesture-based drag-and-drop.
- The PDF report covers the Monday–Sunday week containing the date selected when export is started.
